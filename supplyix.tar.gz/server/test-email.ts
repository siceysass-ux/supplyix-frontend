import { sendSubscriptionReminderEmail } from './src/services/email.service';

// Test email to siceysa@gmail.com
async function testEmail() {
    console.log('Sending test email...');

    const result = await sendSubscriptionReminderEmail(
        'siceysa@gmail.com',
        'Test User',
        '1 Ay Plan',
        new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        7
    );

    console.log('Email sent:', result);
    process.exit(0);
}

testEmail().catch(console.error);
