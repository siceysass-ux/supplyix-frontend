import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { PrismaClient } from '@prisma/client';
import './sentry'; // Initialize Sentry

import path from 'path';
import authRoutes from './routes/auth.routes';
import productRoutes from './routes/products.routes';
import orderRoutes from './routes/orders.routes';
import userRoutes from './routes/users.routes';
import paymentRoutes from './routes/payment.routes';
import profileRoutes from './routes/profile.routes';
import requestRoutes from './routes/requests.routes';
import extraFeesRoutes from './routes/extraFees.routes';
import announcementsRoutes from './routes/announcements.routes';
import supportTicketsRoutes from './routes/supportTickets.routes';
import settingsRoutes from './routes/settings.routes';
import uploadRoutes from './routes/upload.routes';
import categoriesRoutes from './routes/categories.routes';
import cartRoutes from './routes/cart.routes';
import favoritesRoutes from './routes/favorites.routes';
import { startSubscriptionCron } from './services/subscription.cron';
import { startBackupCron } from './services/backup.cron';


dotenv.config();

const app = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // For handling form data from iyzico

// Basic health check
app.get('/health', (req, res) => {
    res.send('Supplyix API is running');
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/users', userRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/requests', requestRoutes);
app.use('/api/extra-fees', extraFeesRoutes);
app.use('/api/announcements', announcementsRoutes);
app.use('/api/support-tickets', supportTicketsRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/categories', categoriesRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/favorites', favoritesRoutes);

// Serve static frontend files
const publicPath = path.join(__dirname, '../public');
app.use(express.static(publicPath));

// Handle SPA routing - return index.html for all non-API routes
app.get('*', (req, res) => {
    res.sendFile(path.join(publicPath, 'index.html'));
});

// Start cron jobs
startSubscriptionCron();
// startBackupCron(); // Temporarily disabled - causing database lock

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
