import express, { Request, Response } from 'express';
import Iyzipay from 'iyzipay';

const router = express.Router();

// iyzico client initialization (conditional)
const iyzipay = process.env.IYZICO_API_KEY && process.env.IYZICO_SECRET_KEY
    ? new Iyzipay({
        apiKey: process.env.IYZICO_API_KEY,
        secretKey: process.env.IYZICO_SECRET_KEY,
        uri: process.env.IYZICO_BASE_URL || 'https://sandbox-api.iyzipay.com'
    })
    : null;

// Payment initialization endpoint
router.post('/initialize', async (req: Request, res: Response) => {
    try {
        if (!iyzipay) {
            return res.status(503).json({ error: 'Payment service not configured' });
        }

        const { item, buyer, card } = req.body;

        // Validate required fields
        if (!item || !buyer || !card) {
            return res.status(400).json({
                success: false,
                error: 'Eksik ödeme bilgileri'
            });
        }

        // Prepare payment request
        const request = {
            locale: Iyzipay.LOCALE.TR,
            conversationId: `conv_${Date.now()}`,
            price: item.price.toString(),
            paidPrice: item.price.toString(),
            currency: Iyzipay.CURRENCY.USD,
            installment: '1',
            basketId: `basket_${Date.now()}`,
            paymentChannel: Iyzipay.PAYMENT_CHANNEL.WEB,
            paymentGroup: Iyzipay.PAYMENT_GROUP.PRODUCT,
            callbackUrl: process.env.PAYMENT_CALLBACK_URL,
            paymentCard: {
                cardHolderName: card.cardHolderName,
                cardNumber: card.cardNumber.replace(/\s/g, ''),
                expireMonth: card.expireMonth,
                expireYear: card.expireYear,
                cvc: card.cvc,
                registerCard: '0'
            },
            buyer: {
                id: buyer.id,
                name: buyer.name,
                surname: buyer.surname,
                gsmNumber: buyer.gsmNumber,
                email: buyer.email,
                identityNumber: buyer.identityNumber || '11111111111',
                lastLoginDate: new Date().toISOString().replace('T', ' ').substring(0, 19),
                registrationDate: buyer.registrationDate || new Date().toISOString().replace('T', ' ').substring(0, 19),
                registrationAddress: buyer.address || 'Adres bilgisi',
                ip: req.ip || '85.34.78.112',
                city: buyer.city || 'Istanbul',
                country: buyer.country || 'Turkey',
                zipCode: buyer.zipCode || '34732'
            },
            shippingAddress: {
                contactName: `${buyer.name} ${buyer.surname}`,
                city: buyer.city || 'Istanbul',
                country: buyer.country || 'Turkey',
                address: buyer.address || 'Adres bilgisi',
                zipCode: buyer.zipCode || '34732'
            },
            billingAddress: {
                contactName: `${buyer.name} ${buyer.surname}`,
                city: buyer.city || 'Istanbul',
                country: buyer.country || 'Turkey',
                address: buyer.address || 'Adres bilgisi',
                zipCode: buyer.zipCode || '34732'
            },
            basketItems: [
                {
                    id: item.id || 'item1',
                    name: item.name,
                    category1: item.category || 'Subscription',
                    category2: item.subcategory || 'Membership',
                    itemType: Iyzipay.BASKET_ITEM_TYPE.VIRTUAL,
                    price: item.price.toString()
                }
            ]
        };

        // Create 3D Secure payment
        iyzipay.threedsInitialize.create(request, (err: any, result: any) => {
            if (err) {
                console.error('iyzico error:', err);
                return res.status(500).json({
                    success: false,
                    error: 'Ödeme başlatılamadı',
                    details: err
                });
            }

            if (result.status === 'success') {
                // Return 3D Secure HTML content
                res.json({
                    success: true,
                    threeDSHtmlContent: result.threeDSHtmlContent,
                    paymentId: result.paymentId,
                    conversationId: result.conversationId
                });
            } else {
                res.status(400).json({
                    success: false,
                    error: result.errorMessage || 'Ödeme başlatılamadı',
                    errorCode: result.errorCode
                });
            }
        });

    } catch (error) {
        console.error('Payment initialization error:', error);
        res.status(500).json({
            success: false,
            error: 'Sunucu hatası'
        });
    }
});

// Payment callback endpoint (after 3D Secure)
router.post('/callback', async (req: Request, res: Response) => {
    try {
        const { paymentId, conversationId, mdStatus } = req.body;

        // Verify 3D Secure authentication
        if (mdStatus !== '1') {
            return res.send(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Ödeme Başarısız</title>
                    <script>
                        window.parent.postMessage({ 
                    success: false,
                    error: 'Ödeme durumu sorgulanamadı'
                });
            }

            res.json({
                success: true,
                status: result.status,
                paymentStatus: result.paymentStatus,
                paidPrice: result.paidPrice,
                currency: result.currency
            });
        });

    } catch (error) {
        console.error('Status check error:', error);
        res.status(500).json({
            success: false,
            error: 'Sunucu hatası'
        });
    }
});

export default router;
