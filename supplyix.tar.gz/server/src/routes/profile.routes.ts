import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

const router = Router();
const prisma = new PrismaClient();

// Update user profile information
router.put('/:id/profile', async (req, res) => {
    try {
        const { fullName, email, companyName } = req.body;
        const user = await prisma.user.update({
            where: { id: req.params.id },
            data: {
                name: fullName,
                email,
                // Note: companyName field might need to be added to schema
            },
        });
        res.json(user);
    } catch (error) {
        console.error('Profile update error:', error);
        res.status(500).json({ error: 'Failed to update profile' });
    }
});

// Update user password
router.put('/:id/password', async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;

        // First verify current password
        const user = await prisma.user.findUnique({
            where: { id: req.params.id },
        });

        if (!user || user.password !== currentPassword) {
            return res.status(401).json({ error: 'Current password is incorrect' });
        }

        // Update password
        const updatedUser = await prisma.user.update({
            where: { id: req.params.id },
            data: { password: newPassword },
        });

        res.json({ message: 'Password updated successfully' });
    } catch (error) {
        console.error('Password update error:', error);
        res.status(500).json({ error: 'Failed to update password' });
    }
});

// Update user avatar
router.put('/:id/avatar', async (req, res) => {
    try {
        const { avatar } = req.body;
        const user = await prisma.user.update({
            where: { id: req.params.id },
            data: { avatar },
        });
        res.json(user);
    } catch (error) {
        console.error('Avatar update error:', error);
        res.status(500).json({ error: 'Failed to update avatar' });
    }
});

export default router;
