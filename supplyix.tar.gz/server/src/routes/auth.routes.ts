import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

const router = Router();
const prisma = new PrismaClient();

// Login
router.post('/login', async (req, res) => {
    console.log('Login attempt:', req.body);
    try {
        const { email, password } = req.body;
        const user = await prisma.user.findUnique({
            where: { email },
        });

        console.log('User found:', user);

        if (!user || user.password !== password) {
            console.log('Password mismatch or user not found');
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Update last login
        await prisma.user.update({
            where: { id: user.id },
            data: { lastLogin: new Date().toISOString() },
        });

        res.json(user);
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Login failed' });
    }
});

// Register
router.post('/register', async (req, res) => {
    try {
        const user = await prisma.user.create({
            data: req.body,
        });
        res.json(user);
    } catch (error) {
        res.status(500).json({ error: 'Registration failed' });
    }
});

export default router;
