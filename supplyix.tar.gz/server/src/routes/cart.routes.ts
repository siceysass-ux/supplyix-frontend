import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

const router = Router();
const prisma = new PrismaClient();

// Get user's cart
router.get('/:userId', async (req, res) => {
    try {
        const { userId } = req.params;
        const cart = await prisma.cart.findUnique({
            where: { userId },
            include: {
                items: {
                    include: {
                        product: true
                    }
                }
            }
        });

        if (!cart) {
            return res.json([]);
        }

        // Transform to match frontend CartItem interface
        const cartItems = cart.items.map(item => ({
            id: item.id,
            product: {
                ...item.product,
                images: JSON.parse(item.product.images),
                price: JSON.parse(item.product.price),
                shippingInfo: item.product.shippingInfo ? JSON.parse(item.product.shippingInfo) : undefined,
                variations: item.product.variations ? JSON.parse(item.product.variations) : [],
                variants: item.product.variants ? JSON.parse(item.product.variants) : [],
                tags: item.product.tags ? JSON.parse(item.product.tags) : [],
            },
            variant: {
                sku: item.variantSku,
                // We need to find the specific variant details from the product variants
                // This is a simplification; ideally we store variant snapshot or fetch it
                ...JSON.parse(item.product.variants || '[]').find((v: any) => v.sku === item.variantSku) || {}
            },
            quantity: item.quantity,
            destination: item.destination as 'eu' | 'usa',
            podFile: undefined, // File objects can't be sent, we send URL if exists
            podFileUrl: item.podFileUrl
        }));

        res.json(cartItems);
    } catch (error) {
        console.error('Error fetching cart:', error);
        res.status(500).json({ error: 'Failed to fetch cart' });
    }
});

// Add item to cart
router.post('/add', async (req, res) => {
    try {
        const { userId, product, variant, quantity, destination, podFileUrl } = req.body;

        let cart = await prisma.cart.findUnique({ where: { userId } });

        if (!cart) {
            cart = await prisma.cart.create({ data: { userId } });
        }

        // Check if item exists
        const existingItem = await prisma.cartItem.findFirst({
            where: {
                cartId: cart.id,
                productId: product.id,
                variantSku: variant.sku,
                destination
            }
        });

        if (existingItem) {
            await prisma.cartItem.update({
                where: { id: existingItem.id },
                data: { quantity: existingItem.quantity + quantity }
            });
        } else {
            await prisma.cartItem.create({
                data: {
                    cartId: cart.id,
                    productId: product.id,
                    variantSku: variant.sku,
                    quantity,
                    destination,
                    podFileUrl
                }
            });
        }

        res.json({ success: true });
    } catch (error) {
        console.error('Error adding to cart:', error);
        res.status(500).json({ error: 'Failed to add to cart' });
    }
});

// Update cart item quantity
router.put('/update', async (req, res) => {
    try {
        const { userId, itemId, quantity } = req.body;

        // We need to find the cart item by its ID, but ensure it belongs to the user's cart
        // For simplicity, we'll trust the itemId for now, but in prod verify ownership

        if (quantity <= 0) {
            await prisma.cartItem.delete({ where: { id: itemId } });
        } else {
            await prisma.cartItem.update({
                where: { id: itemId },
                data: { quantity }
            });
        }

        res.json({ success: true });
    } catch (error) {
        console.error('Error updating cart:', error);
        res.status(500).json({ error: 'Failed to update cart' });
    }
});

// Remove item from cart
router.delete('/:itemId', async (req, res) => {
    try {
        const { itemId } = req.params;
        await prisma.cartItem.delete({ where: { id: itemId } });
        res.json({ success: true });
    } catch (error) {
        console.error('Error removing from cart:', error);
        res.status(500).json({ error: 'Failed to remove from cart' });
    }
});

// Clear cart
router.post('/clear', async (req, res) => {
    try {
        const { userId } = req.body;
        const cart = await prisma.cart.findUnique({ where: { userId } });
        if (cart) {
            await prisma.cartItem.deleteMany({ where: { cartId: cart.id } });
        }
        res.json({ success: true });
    } catch (error) {
        console.error('Error clearing cart:', error);
        res.status(500).json({ error: 'Failed to clear cart' });
    }
});

export default router;
